<!DOCTYPE html>
<html lang="">

<head>
    <title>
        WebPageProject
    </title>

    <!-- Literata Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Literata&display=swap">
    <!-- FontAwesome Library CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
<main>


