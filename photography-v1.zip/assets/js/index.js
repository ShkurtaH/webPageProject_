// window.onscroll = function(event) {
//     //
//     if(window.scrollTo > 50){
//         document.getElementsByClassName("header").classList.add("sticky");
//     }
//     else{
//         document.getElementsByClassName("header").classList.remove("sticky");
//     }
// };