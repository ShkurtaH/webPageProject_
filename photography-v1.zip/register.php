<?php include('layout/header.php');
?>
<?php require ('db/db.php') ?>

<main>
    <!--Main Starts-->
    <!-- Banner Starts -->
    <section class="banner"
             style="background-image: linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.5)), url('assets/images/general/LogIn-Register-Banner.jpg'); background-position: center;padding: 0 0 190px 0; background-size: cover;">
        <div class="header">
            <div class="logo">
                <figure>
                    <a href="index.php">
                        <img src="assets/images/icons/logo[photography].png" alt="Logo">
                    </a>
                </figure>
            </div>
            <div class="navigation">
                <ul>
                    <li>
                        <a href="index.php">Home</a>
                    </li>
                    <li>
                        <a href="about.php"> About</a>
                    </li>
                    <li>
                        <a href="portfolio.php">Portfolio</a>
                    </li>
                    <li>
                        <a href="contact.php" >Contact</a>
                    </li>
                </ul>
            </div>
            <div class="login">
                <a href="register.php" class="btn">SIGN UP</a>
            </div>
        </div>
        <div class="banner-content">
            <p>
                “To me, photography is an art of observation. It’s about finding something interesting in an ordinary place… I’ve found it has little to do with the things you see and everything to do with the way you see them.”
            </p>
        </div>
    </section>
    <div class="contact-info space">
        <div class="flex">
            <form name="registration" action="" method="post" id="registerForm" class="register-form">
                <h3>Don't have an account? / Register Form</h3>
                <div class="form-wrapper">
                    <div class="form-group">
                        <input type="text" name="username" value="" placeholder="First Name" class="main-input"
                               id="first-name" >
                        <div id="first-name-error" class="text-error"></div>
                    </div>
                    <div class="form-group">
                        <input type="email" name="email" value="" placeholder="E-Mail" class="main-input"
                               id="register-email" >
                        <div id="email-register-error" class="text-error"></div>
                    </div>
                    <div class="form-group">
                        <input type="password" name="password" value="" placeholder="Password" class="main-input"
                               id="pwd-register" >
                        <div id="pwd-register-error" class="text-error"></div>
                    </div>
                    <div class="form-group">
                        <p>If you already registered, <a href="login.php">Login</a></p>
                    </div>
                    <div class="form-group-submit-wrapper flex">
                        <button type="submit" class="btn" id="registerBtn" name="registerBtn">Register</button>
                    </div>
                </div>
            </form>

        </div>

    </div>
</main>


    <script>

        var button = document.getElementById("registerBtn");

        var username = document.forms["registerForm"]["username"];
        var email = document.forms["registerForm"]["email"];
        var password = document.forms["registerForm"]["password"];

        var emailRegEx = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
        var passwordRegEx = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/

        var firstName_error= document.getElementById("first-name-error");
        var email_error = document.getElementById("email-register-error");
        var password_error = document.getElementById("pwd-register-error");

        username.addEventListener("blur", verifyUsername, true);
        email.addEventListener("blur", verifyEmail, true);
        // password.addEventListener("blur", verifyPassword, true);


        function verifyUsername() {
            if (username.value != "") {
                firstName_error.innerHTML = "";
                return true;
            }
        }

        function verifyEmail() {

            if (email.value != "") {
                email_error.innerHTML = "";
                return true;
            } else {
                if (emailRegEx.test(email)) {
                    email_error.innerHTML = "";
                } else {
                    email_error.textContent = "Email should be something like this : shkurtahoxha@gmail.com";
                    event.preventDefault();
                }
            }

        }

        function verifyPassword(){

            if(password.value != ""){
                password_error.innerHTML = "";
            }else{
                if (passwordRegEx.test(password)){
                    password_error.innerHTML = "";
                }else{
                    password_error.textContent = "Password should have minimum eight characters, at least one Uppercase, one Lowercase letter and one Number!";
                    event.preventDefault();
                }
            }
        }

        button.addEventListener("click", function (event) {

            if (username.value == "") {
                firstName_error.textContent = 'This field is a required field.';
                username.focus();
                event.preventDefault();
            }

            if (email.value == "") {
                email_error.textContent = "This field is a required field.";
                email.focus();
                event.preventDefault();
            } else {
                if (emailRegEx.test(email.value)) {
                    email_error.innerText = "";
                } else {
                    email_error.innerText = "Email must be something like this: shkurtahoxha@gmail.com!";
                    event.preventDefault();
                }

            }
            if (password.value == "") {
                password_error.textContent = "This field is a required field.";
                password.focus();
                event.preventDefault();
            } else {
                if (passwordRegEx.test(password.value)) {
                    password_error.innerText = "";
                } else {
                    password_error.innerText = "Password should have minimum eight characters, at least one Uppercase, one Lowercase letter and one Number!";
                    event.preventDefault();
                }

            }
        });

    </script>

<?php include('layout/footer.php') ?>


